package com.example.webview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    WebView webview;
    Button next;
    Button back;
    Button reload;
    Button bigger;
    Button smaller;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webview = findViewById(R.id.webview);
        webview.setWebViewClient(new WebViewClient());
        webview.loadUrl("https://www.google.com/");

        next = findViewById(R.id.next);
        back = findViewById(R.id.back);
        reload = findViewById(R.id.reload);
        bigger = findViewById(R.id.bigger);
        smaller = findViewById(R.id.smaller);

        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.reload();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.goBack();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.goForward();
            }
        });
        bigger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.zoomIn();
            }
        });
        smaller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                webview.zoomOut();
            }
        });

    }
}